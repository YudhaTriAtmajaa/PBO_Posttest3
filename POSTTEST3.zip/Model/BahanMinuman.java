package Model;

public class BahanMinuman extends Bahan {
    private boolean berkarbonasi;

    public BahanMinuman(String nama, int stok, String satuan, String kadaluarsa, boolean berkarbonasi) {
        super(nama, stok, satuan, kadaluarsa);
        this.berkarbonasi = berkarbonasi;
    }

    public boolean isBerkarbonasi() {
        return berkarbonasi;
    }

    public void setBerkarbonasi(boolean berkarbonasi) {
        this.berkarbonasi = berkarbonasi;
    }

    // Overriding info()
    @Override
    public String info() {
        return super.info() + " | Berkarbonasi: " + (berkarbonasi ? "Ya" : "Tidak");
    }
}
