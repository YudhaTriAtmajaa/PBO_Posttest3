package Model;

public class BahanInstant extends Bahan {
    private boolean halal;

    public BahanInstant(String nama, int stok, String satuan, String kadaluarsa, boolean halal) {
        super(nama, stok, satuan, kadaluarsa);
        this.halal = halal;
    }

    public boolean isHalal() {
        return halal;
    }

    public void setHalal(boolean halal) {
        this.halal = halal;
    }

    // Overriding info()
    @Override
    public String info() {
        return super.info() + " | Halal: " + (halal ? "Ya" : "Tidak");
    }
}
